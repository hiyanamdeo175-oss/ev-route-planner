import React, { createContext, useState } from 'react';

export const EVContext = createContext();

export const EVProvider = ({ children }) => {
  const [battery, setBattery] = useState(78);
  const [range, setRange] = useState(210);
  const [booking, setBooking] = useState(null);

  // Add route state with default empty values
  const [route, setRoute] = useState({
    startCoords: null,
    destCoords: null,
    startLabel: '',
    destLabel: ''
  });

  return (
    <EVContext.Provider value={{
      battery, setBattery,
      range, setRange,
      booking, setBooking,
      route, setRoute   // <-- IMPORTANT: must include this!
    }}>
      {children}
    </EVContext.Provider>
  );
};
