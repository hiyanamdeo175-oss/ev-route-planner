import React, { useState, useContext, useRef, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-routing-machine/dist/leaflet-routing-machine.css';
import { EVContext } from './EVContext';

const startIcon = new L.Icon({
  iconUrl: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

const destIcon = new L.Icon({
  iconUrl: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

function RoutePlanning() {
  const { route, setRoute } = useContext(EVContext);
  const [start, setStart] = useState('');
  const [destination, setDestination] = useState('');
  const mapRef = useRef(null);
  const routingRef = useRef(null);

  // Geocode using Nominatim
  const geocode = async (address) => {
    try {
      const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${address}`);
      const data = await res.json();
      if (data.length > 0) return [parseFloat(data[0].lat), parseFloat(data[0].lon)];
      return null;
    } catch (err) {
      console.error(err);
      return null;
    }
  };

  const handleRoute = async () => {
    if (!start || !destination) return alert('Enter both start and destination');
    const startCoords = await geocode(start);
    const destCoords = await geocode(destination);
    if (!startCoords || !destCoords) return alert('Location not found');
    setRoute({ startCoords, destCoords, startLabel: start, destLabel: destination });
  };

  useEffect(() => {
    if (!mapRef.current) return;
    const map = mapRef.current;

    // Remove old routing control
    if (routingRef.current) {
      routingRef.current.remove();
      routingRef.current = null;
    }

    // Add new routing control if route exists
    if (route?.startCoords && route?.destCoords) {
      routingRef.current = L.Routing.control({
        waypoints: [
          L.latLng(...route.startCoords),
          L.latLng(...route.destCoords),
        ],
        routeWhileDragging: false,
        show: false,
        lineOptions: { styles: [{ color: 'blue', opacity: 0.6, weight: 4 }] },
        addWaypoints: false,
        createMarker: () => null, // we use custom markers
      }).addTo(map);
      map.fitBounds([
        route.startCoords,
        route.destCoords
      ]);
    }
  }, [route]);

  const centerMap = route?.startCoords || [18.5204, 73.8567];

  return (
    <div style={{ padding: '20px' }}>
      <h2>Route Planning</h2>
      <div style={{ display: 'flex', gap: '10px', marginBottom: '15px' }}>
        <input
          placeholder="Start Point"
          value={start}
          onChange={(e) => setStart(e.target.value)}
          style={{ flex: 1, padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }}
        />
        <input
          placeholder="Destination"
          value={destination}
          onChange={(e) => setDestination(e.target.value)}
          style={{ flex: 1, padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }}
        />
        <button
          onClick={handleRoute}
          style={{ padding: '10px 20px', borderRadius: '5px', border: 'none', background: '#2c3e50', color: 'white', cursor: 'pointer' }}
        >
          Show Route
        </button>
      </div>
      <div style={{ height: '450px', width: '100%', borderRadius: '10px', overflow: 'hidden' }}>
        <MapContainer
          center={centerMap}
          zoom={13}
          style={{ height: '100%', width: '100%' }}
          whenCreated={(map) => (mapRef.current = map)}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution="© OpenStreetMap contributors"
          />
          {route?.startCoords && <Marker position={route.startCoords} icon={startIcon}><Popup>{route.startLabel}</Popup></Marker>}
          {route?.destCoords && <Marker position={route.destCoords} icon={destIcon}><Popup>{route.destLabel}</Popup></Marker>}
        </MapContainer>
      </div>
    </div>
  );
}

export default RoutePlanning;
