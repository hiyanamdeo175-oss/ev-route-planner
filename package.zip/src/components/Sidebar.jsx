import React from 'react';
import { Link } from 'react-router-dom';
import './Sidebar.css';

function Sidebar() {
  return (
    <div className="sidebar">
      <h2>⚡ EV Route Planner</h2>
      <ul>
        <li><Link to="/">Dashboard</Link></li>
        <li><Link to="/route">Route Planning</Link></li>
        <li><Link to="/battery">Battery & Charging</Link></li>
      </ul>
    </div>
  );
}

export default Sidebar;
