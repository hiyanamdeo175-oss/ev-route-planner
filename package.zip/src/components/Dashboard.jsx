import React, { useContext, useEffect, useState, useRef } from 'react';
import { EVContext } from './EVContext';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import 'leaflet-routing-machine/dist/leaflet-routing-machine.css';

// Fix Leaflet marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// Custom markers
const startIcon = new L.Icon({
  iconUrl: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

const destIcon = new L.Icon({
  iconUrl: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

function Dashboard() {
  const { battery, range, booking, route } = useContext(EVContext);
  const [position, setPosition] = useState(null);
  const mapRef = useRef(null);
  const routingRef = useRef(null);

  // Get current location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setPosition([pos.coords.latitude, pos.coords.longitude]),
        (err) => console.error('Error fetching location:', err)
      );
    }
  }, []);

  // Update routing whenever the route changes
  useEffect(() => {
    if (!mapRef.current) return;
    const map = mapRef.current;

    // Remove old routing
    if (routingRef.current) {
      routingRef.current.remove();
      routingRef.current = null;
    }

    if (route?.startCoords && route?.destCoords) {
      routingRef.current = L.Routing.control({
        waypoints: [
          L.latLng(...route.startCoords),
          L.latLng(...route.destCoords),
        ],
        routeWhileDragging: false,
        show: false,
        lineOptions: { styles: [{ color: 'blue', opacity: 0.6, weight: 4 }] },
        addWaypoints: false,
        createMarker: () => null, // use custom markers
      }).addTo(map);

      map.fitBounds([route.startCoords, route.destCoords]);
    }
  }, [route]);

  const centerMap = route?.startCoords || position || [18.5204, 73.8567];

  return (
    <div style={{ padding: '20px' }}>
      <h2>Dashboard</h2>
      {/* Info Blocks */}
      <div style={{ display: 'flex', gap: '15px', marginBottom: '15px' }}>
        {['Battery', 'Range', 'Nearest Station', 'Trip Distance'].map((label) => (
          <div key={label} style={{ flex: 1, background: '#2c3e50', color: 'white', borderRadius: '8px', padding: '20px', textAlign: 'center' }}>
            <div style={{ fontSize: '14px', opacity: 0.8 }}>{label}</div>
            <div style={{ fontSize: '20px', fontWeight: 600, marginTop: '8px' }}>
              {label === 'Battery' ? battery + '%' :
               label === 'Range' ? range + ' km' :
               label === 'Nearest Station' ? '5 km' : '120 km'}
            </div>
          </div>
        ))}
      </div>

      <h3>Current Location & Route</h3>
      <div style={{ height: '450px', width: '100%', borderRadius: '10px', overflow: 'hidden' }}>
        <MapContainer
          center={centerMap}
          zoom={13}
          style={{ height: '100%', width: '100%' }}
          whenCreated={(map) => (mapRef.current = map)}
        >
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution="© OpenStreetMap contributors"
          />
          {/* Current location marker */}
          {position && <Marker position={position}><Popup>You are here 📍</Popup></Marker>}

          {/* Start & Destination markers */}
          {route?.startCoords && <Marker position={route.startCoords} icon={startIcon}><Popup>{route.startLabel}</Popup></Marker>}
          {route?.destCoords && <Marker position={route.destCoords} icon={destIcon}><Popup>{route.destLabel}</Popup></Marker>}
        </MapContainer>
      </div>
    </div>
  );
}

export default Dashboard;
