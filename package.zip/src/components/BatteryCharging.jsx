import React, { useContext, useState } from 'react';
import { EVContext } from './EVContext';

function BatteryCharging() {
  const { battery, setBattery, range, setRange, booking, setBooking } = useContext(EVContext);

  const [newBattery, setNewBattery] = useState(battery);
  const [newRange, setNewRange] = useState(range);
  const [station, setStation] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');

  const updateValues = () => {
    setBattery(newBattery);
    setRange(newRange);
  };

  const handleBooking = () => {
    if (!station || !startTime || !endTime) {
      alert('⚠️ Please fill all fields before booking.');
      return;
    }
    if (endTime <= startTime) {
      alert('End time must be later than start time.');
      return;
    }
    setBooking({ station, startTime, endTime });
    alert(`✅ Charging station booked at ${station} from ${startTime} to ${endTime}`);
  };

  return (
    <div className="page-container">
      <h2>Battery & Charging</h2>

      <div className="battery-section">
        <div className="battery-circle">{battery}%</div>
        <div className="battery-info">
          <p>Range Remaining: {range} km</p>
          <p>Energy Consumption: 14.2 kWh/100km</p>
        </div>
      </div>

      <h4>Update Battery Info</h4>
      <label>Battery (%)</label>
      <input type="number" value={newBattery} onChange={(e) => setNewBattery(e.target.value)} />
      <label>Range (km)</label>
      <input type="number" value={newRange} onChange={(e) => setNewRange(e.target.value)} />
      <button onClick={updateValues}>Save</button>

      <hr style={{ margin: '20px 0' }} />

      <h3>⚡ Book Charging Station</h3>
      <label>Select Station</label>
      <select value={station} onChange={(e) => setStation(e.target.value)}>
        <option value="">-- Choose a station --</option>
        <option value="Tata Power - Baner">Tata Power - Baner</option>
        <option value="ChargeGrid - Kothrud">ChargeGrid - Kothrud</option>
        <option value="Jio BP - Viman Nagar">Jio BP - Viman Nagar</option>
      </select>

      <label>Start Time</label>
      <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />

      <label>End Time</label>
      <input type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />

      <button onClick={handleBooking} style={{ marginTop: '10px' }}>
        Book Station
      </button>

      {booking && (
        <div className="summary" style={{ marginTop: '15px' }}>
          <strong>Active Booking:</strong>
          <p>Station: {booking.station}</p>
          <p>Start Time: {booking.startTime}</p>
          <p>End Time: {booking.endTime}</p>
        </div>
      )}
    </div>
  );
}

export default BatteryCharging;
