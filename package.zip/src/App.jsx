import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar.jsx';
import Dashboard from './components/Dashboard.jsx';
import RoutePlanning from './components/RoutePlanning.jsx';
import BatteryCharging from './components/BatteryCharging.jsx';
import { EVProvider } from './components/EVContext.jsx';
import './App.css';

function App() {
  return (
    <EVProvider>
      <Router>
        <div className="app-container" style={{ display: 'flex', minHeight: '100vh' }}>
          {/* Sidebar */}
          <Sidebar />

          {/* Main content */}
          <div className="main-content" style={{ flex: 1, padding: '20px' }}>
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/route" element={<RoutePlanning />} />
              <Route path="/battery" element={<BatteryCharging />} />
            </Routes>
          </div>
        </div>
      </Router>
    </EVProvider>
  );
}

export default App;
